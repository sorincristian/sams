import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "./prisma.js";
import { requireAuth, signToken, type AuthRequest } from "./auth.js";

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",") ?? "*", credentials: false }));
app.use(express.json());
app.use(morgan("dev"));

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "sams-api" });
});

app.post("/api/auth/login", async (req, res) => {
  const schema = z.object({
    email: z.string().email(),
    password: z.string().min(1)
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid request" });

  const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });
  if (!user) return res.status(401).json({ message: "Invalid credentials" });

  const ok = await bcrypt.compare(parsed.data.password, user.passwordHash);
  if (!ok) return res.status(401).json({ message: "Invalid credentials" });

  const token = signToken({ sub: user.id, email: user.email, role: user.role });
  res.json({
    token,
    user: { id: user.id, email: user.email, name: user.name, role: user.role }
  });
});

app.get("/api/auth/me", requireAuth, async (req: AuthRequest, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.user!.sub } });
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json({ id: user.id, email: user.email, name: user.name, role: user.role });
});

app.get("/api/dashboard", requireAuth, async (_req, res) => {
  const [garages, buses, seatInsertTypes, openWorkOrders, inventoryRows, recentWorkOrders] = await Promise.all([
    prisma.garage.count(),
    prisma.bus.count(),
    prisma.seatInsertType.count(),
    prisma.workOrder.count({ where: { status: "OPEN" } }),
    prisma.inventoryItem.findMany({
      include: { garage: true, seatInsertType: true }
    }),
    prisma.workOrder.findMany({
      include: {
        bus: { include: { garage: true } }
      },
      orderBy: { createdAt: "desc" },
      take: 5
    })
  ]);

  const lowStock = inventoryRows
    .filter((row) => row.quantity <= row.seatInsertType.minStockLevel)
    .map((row) => ({
      garage: row.garage.name,
      partNumber: row.seatInsertType.partNumber,
      description: row.seatInsertType.description,
      quantity: row.quantity,
      minStockLevel: row.seatInsertType.minStockLevel
    }));

  res.json({
    counts: { garages, buses, seatInsertTypes, openWorkOrders },
    lowStock,
    recentWorkOrders
  });
});

app.get("/api/garages", requireAuth, async (_req, res) => {
  const garages = await prisma.garage.findMany({ orderBy: { name: "asc" } });
  res.json(garages);
});

app.get("/api/buses", requireAuth, async (_req, res) => {
  const buses = await prisma.bus.findMany({
    include: { garage: true },
    orderBy: { fleetNumber: "asc" }
  });
  res.json(buses);
});

app.get("/api/inventory", requireAuth, async (_req, res) => {
  const inventory = await prisma.inventoryItem.findMany({
    include: { garage: true, seatInsertType: true },
    orderBy: [{ garage: { name: "asc" } }, { seatInsertType: { partNumber: "asc" } }]
  });
  res.json(inventory);
});

app.post("/api/inventory/adjust", requireAuth, async (req, res) => {
  const schema = z.object({
    inventoryItemId: z.string(),
    quantity: z.number().int().min(0)
  });
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid request" });

  const updated = await prisma.inventoryItem.update({
    where: { id: parsed.data.inventoryItemId },
    data: { quantity: parsed.data.quantity },
    include: { garage: true, seatInsertType: true }
  });

  res.json(updated);
});

app.get("/api/work-orders", requireAuth, async (_req, res) => {
  const workOrders = await prisma.workOrder.findMany({
    include: { bus: { include: { garage: true } } },
    orderBy: { createdAt: "desc" }
  });
  res.json(workOrders);
});

app.post("/api/work-orders", requireAuth, async (req, res) => {
  const schema = z.object({
    busId: z.string(),
    issueDescription: z.string().min(3),
    priority: z.enum(["LOW", "MEDIUM", "HIGH"]).default("MEDIUM")
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid request" });

  const bus = await prisma.bus.findUnique({ where: { id: parsed.data.busId } });
  if (!bus) return res.status(404).json({ message: "Bus not found" });

  const count = await prisma.workOrder.count();
  const created = await prisma.workOrder.create({
    data: {
      workOrderNumber: `WO-${1000 + count + 1}`,
      issueDescription: parsed.data.issueDescription,
      priority: parsed.data.priority,
      busId: bus.id,
      garageId: bus.garageId
    },
    include: { bus: { include: { garage: true } } }
  });

  res.status(201).json(created);
});

app.use((_req, res) => {
  res.status(404).json({ message: "Not found" });
});

export default app;
