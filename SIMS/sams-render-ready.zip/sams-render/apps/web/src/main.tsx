import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, NavLink, Route, Routes, useNavigate } from "react-router-dom";
import { api, setAuthToken } from "./api";
import type { Bus, DashboardResponse, InventoryRow, WorkOrder } from "@sams/types";

function useAuth() {
  const [token, setToken] = React.useState<string | null>(localStorage.getItem("sams_token"));
  const [user, setUser] = React.useState<{ name: string; email: string; role: string } | null>(null);

  React.useEffect(() => {
    if (!token) return;
    api.get("/auth/me").then((res) => setUser(res.data)).catch(() => {
      setAuthToken(null);
      setToken(null);
    });
  }, [token]);

  return { token, setToken, user, setUser };
}

function Login({ onLogin }: { onLogin: (token: string) => void }) {
  const navigate = useNavigate();
  const [email, setEmail] = React.useState("admin@sams.local");
  const [password, setPassword] = React.useState("password123");
  const [error, setError] = React.useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      const res = await api.post("/auth/login", { email, password });
      setAuthToken(res.data.token);
      onLogin(res.data.token);
      navigate("/");
    } catch {
      setError("Invalid credentials");
    }
  }

  return (
    <div className="login">
      <h1>SAMS</h1>
      <p className="muted">Seat Inserts Management System</p>
      <form className="row" onSubmit={submit}>
        <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
        <input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" type="password" />
        <button type="submit">Sign in</button>
        {error ? <div className="muted">{error}</div> : null}
      </form>
    </div>
  );
}

function Shell({ user, onLogout }: { user: { name: string; role: string } | null; onLogout: () => void }) {
  return (
    <div className="shell">
      <aside className="sidebar">
        <h2>SAMS</h2>
        <p className="muted" style={{ color: "#9ca3af" }}>TTC Seat Inventory</p>
        <nav>
          <NavLink to="/" end className={({ isActive }) => (isActive ? "active" : "")}>Dashboard</NavLink>
          <NavLink to="/fleet" className={({ isActive }) => (isActive ? "active" : "")}>Fleet</NavLink>
          <NavLink to="/inventory" className={({ isActive }) => (isActive ? "active" : "")}>Inventory</NavLink>
          <NavLink to="/work-orders" className={({ isActive }) => (isActive ? "active" : "")}>Work Orders</NavLink>
        </nav>
      </aside>
      <main className="content">
        <div className="topbar">
          <div>
            <strong>{user?.name ?? "User"}</strong>
            <div className="muted">{user?.role}</div>
          </div>
          <button style={{ width: "auto" }} onClick={onLogout}>Sign out</button>
        </div>
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/fleet" element={<FleetPage />} />
          <Route path="/inventory" element={<InventoryPage />} />
          <Route path="/work-orders" element={<WorkOrdersPage />} />
        </Routes>
      </main>
    </div>
  );
}

function DashboardPage() {
  const [data, setData] = React.useState<DashboardResponse | null>(null);
  React.useEffect(() => {
    api.get("/dashboard").then((res) => setData(res.data));
  }, []);
  if (!data) return <div className="card">Loading...</div>;

  return (
    <div className="grid" style={{ gap: 20 }}>
      <h1>Dashboard</h1>
      <div className="grid stats">
        <div className="card"><strong>{data.counts.garages}</strong><div className="muted">Garages</div></div>
        <div className="card"><strong>{data.counts.buses}</strong><div className="muted">Buses</div></div>
        <div className="card"><strong>{data.counts.seatInsertTypes}</strong><div className="muted">Seat insert types</div></div>
        <div className="card"><strong>{data.counts.openWorkOrders}</strong><div className="muted">Open work orders</div></div>
      </div>
      <div className="grid two">
        <div className="card">
          <h3>Low stock</h3>
          <table>
            <thead><tr><th>Garage</th><th>Part</th><th>Qty</th></tr></thead>
            <tbody>
              {data.lowStock.length === 0 ? <tr><td colSpan={3}>No low stock items.</td></tr> :
                data.lowStock.map((row) => (
                  <tr key={`${row.garage}-${row.partNumber}`}>
                    <td>{row.garage}</td>
                    <td>{row.partNumber}</td>
                    <td>{row.quantity} / min {row.minStockLevel}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
        <div className="card">
          <h3>Recent work orders</h3>
          <table>
            <thead><tr><th>WO</th><th>Bus</th><th>Status</th></tr></thead>
            <tbody>
              {data.recentWorkOrders.map((wo) => (
                <tr key={wo.id}>
                  <td>{wo.workOrderNumber}</td>
                  <td>{wo.bus.fleetNumber}</td>
                  <td>{wo.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function FleetPage() {
  const [rows, setRows] = React.useState<Bus[]>([]);
  React.useEffect(() => { api.get("/buses").then((res) => setRows(res.data)); }, []);
  return (
    <div className="grid">
      <h1>Fleet</h1>
      <div className="card">
        <table>
          <thead><tr><th>Fleet</th><th>Model</th><th>Manufacturer</th><th>Garage</th><th>Status</th></tr></thead>
          <tbody>
            {rows.map((bus) => (
              <tr key={bus.id}>
                <td>{bus.fleetNumber}</td>
                <td>{bus.model}</td>
                <td>{bus.manufacturer}</td>
                <td>{bus.garage?.name}</td>
                <td>{bus.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function InventoryPage() {
  const [rows, setRows] = React.useState<InventoryRow[]>([]);
  React.useEffect(() => { api.get("/inventory").then((res) => setRows(res.data)); }, []);
  return (
    <div className="grid">
      <h1>Inventory</h1>
      <div className="card">
        <table>
          <thead><tr><th>Garage</th><th>Part</th><th>Description</th><th>Qty</th></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{row.garage.name}</td>
                <td>{row.seatInsertType.partNumber}</td>
                <td>{row.seatInsertType.description}</td>
                <td>{row.quantity}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function WorkOrdersPage() {
  const [rows, setRows] = React.useState<WorkOrder[]>([]);
  const [buses, setBuses] = React.useState<Bus[]>([]);
  const [busId, setBusId] = React.useState("");
  const [issueDescription, setIssueDescription] = React.useState("");

  async function load() {
    const [woRes, busRes] = await Promise.all([api.get("/work-orders"), api.get("/buses")]);
    setRows(woRes.data);
    setBuses(busRes.data);
    if (!busId && busRes.data[0]) setBusId(busRes.data[0].id);
  }

  React.useEffect(() => { void load(); }, []);

  async function createWorkOrder(e: React.FormEvent) {
    e.preventDefault();
    if (!busId || !issueDescription.trim()) return;
    await api.post("/work-orders", { busId, issueDescription, priority: "MEDIUM" });
    setIssueDescription("");
    await load();
  }

  return (
    <div className="grid" style={{ gap: 20 }}>
      <h1>Work Orders</h1>
      <div className="grid two">
        <div className="card">
          <h3>Create work order</h3>
          <form className="row" onSubmit={createWorkOrder}>
            <select value={busId} onChange={(e) => setBusId(e.target.value)}>
              {buses.map((bus) => <option key={bus.id} value={bus.id}>{bus.fleetNumber} - {bus.model}</option>)}
            </select>
            <textarea value={issueDescription} onChange={(e) => setIssueDescription(e.target.value)} placeholder="Issue description" rows={4} />
            <button type="submit">Create</button>
          </form>
        </div>
        <div className="card">
          <h3>Open work orders</h3>
          <table>
            <thead><tr><th>WO</th><th>Bus</th><th>Priority</th><th>Status</th></tr></thead>
            <tbody>
              {rows.map((wo) => (
                <tr key={wo.id}>
                  <td>{wo.workOrderNumber}</td>
                  <td>{wo.bus.fleetNumber}</td>
                  <td>{wo.priority}</td>
                  <td>{wo.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function App() {
  const auth = useAuth();

  function logout() {
    setAuthToken(null);
    auth.setToken(null);
    auth.setUser(null);
  }

  return auth.token ? <Shell user={auth.user} onLogout={logout} /> : <Routes><Route path="*" element={<Login onLogin={auth.setToken} />} /></Routes>;
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
