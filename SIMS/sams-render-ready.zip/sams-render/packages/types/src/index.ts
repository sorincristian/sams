export type Role = "ADMIN" | "GARAGE_MANAGER" | "TECHNICIAN";

export interface Garage {
  id: string;
  code: string;
  name: string;
}

export interface Bus {
  id: string;
  fleetNumber: string;
  model: string;
  manufacturer: string;
  garageId: string;
  status: string;
  garage?: Garage;
}

export interface SeatInsertType {
  id: string;
  partNumber: string;
  description: string;
  vendor: string;
  minStockLevel: number;
}

export interface InventoryRow {
  id: string;
  quantity: number;
  garage: Garage;
  seatInsertType: SeatInsertType;
}

export interface WorkOrder {
  id: string;
  workOrderNumber: string;
  status: string;
  priority: string;
  issueDescription: string;
  bus: Bus;
  createdAt: string;
}

export interface DashboardResponse {
  counts: {
    garages: number;
    buses: number;
    seatInsertTypes: number;
    openWorkOrders: number;
  };
  lowStock: Array<{
    garage: string;
    partNumber: string;
    description: string;
    quantity: number;
    minStockLevel: number;
  }>;
  recentWorkOrders: WorkOrder[];
}
